# PDR Anket Paneli

Kurulum ve yayına alma adımları için `KURULUM-REHBERI.md` dosyasına bakın.

## Yerel bilgisayarınızda deneme (isteğe bağlı)

```
pip install -r requirements.txt
python app.py
```

Sonra tarayıcıdan `http://127.0.0.1:5000` adresine gidin.
Varsayılan giriş: kullanıcı adı `ogretmen`, şifre `degistir123`
(gerçek yayında bunları mutlaka değiştirin — rehbere bakın).
