import os
import io
import csv
import json
import sqlite3
import secrets
from functools import wraps
from datetime import datetime, timezone

from flask import (
    Flask, request, session, redirect, url_for, render_template,
    g, flash, abort, Response
)
import qrcode

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join(APP_DIR, "data", "anket.db"))
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "gelistirme-icin-degistirin")
app.jinja_env.filters["from_json"] = json.loads

ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "ogretmen")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "degistir123")


# ---------- Veritabanı ----------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS surveys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            published INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            survey_id INTEGER NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
            position INTEGER NOT NULL,
            qtype TEXT NOT NULL,            -- choice | likert | open
            text TEXT NOT NULL,
            options_json TEXT DEFAULT '[]'
        );

        -- Kimlik bilgisi: sadece kimin katıldığını/katılmadığını izlemek için.
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            survey_id INTEGER NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
            full_name TEXT NOT NULL,
            student_no TEXT NOT NULL,
            token TEXT UNIQUE NOT NULL,
            used INTEGER DEFAULT 0,
            used_at TEXT
        );

        -- Cevaplar: hiçbir öğrenci kimliğine referans vermez, bilerek ayrık tutulur.
        CREATE TABLE IF NOT EXISTS responses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            survey_id INTEGER NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
            answers_json TEXT NOT NULL,
            submitted_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        """
    )
    db.commit()
    db.close()


# ---------- Yetkilendirme ----------

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username", "")
        p = request.form.get("password", "")
        if u == ADMIN_USERNAME and p == ADMIN_PASSWORD:
            session["logged_in"] = True
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Kullanıcı adı veya şifre hatalı.")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------- Öğretmen paneli ----------

@app.route("/")
@login_required
def dashboard():
    db = get_db()
    surveys = db.execute(
        """
        SELECT s.*,
               (SELECT COUNT(*) FROM students st WHERE st.survey_id = s.id) AS total_students,
               (SELECT COUNT(*) FROM students st WHERE st.survey_id = s.id AND st.used = 1) AS filled,
               (SELECT COUNT(*) FROM questions q WHERE q.survey_id = s.id) AS q_count
        FROM surveys s ORDER BY s.created_at DESC
        """
    ).fetchall()
    return render_template("dashboard.html", surveys=surveys)


@app.route("/survey/new", methods=["GET", "POST"])
@login_required
def survey_new():
    if request.method == "POST":
        db = get_db()
        cur = db.execute(
            "INSERT INTO surveys (title, description) VALUES (?, ?)",
            (request.form.get("title", "Adsız anket"), request.form.get("description", "")),
        )
        db.commit()
        return redirect(url_for("survey_edit", survey_id=cur.lastrowid))
    return redirect(url_for("dashboard"))


@app.route("/survey/<int:survey_id>/edit", methods=["GET", "POST"])
@login_required
def survey_edit(survey_id):
    db = get_db()
    survey = db.execute("SELECT * FROM surveys WHERE id = ?", (survey_id,)).fetchone()
    if not survey:
        abort(404)

    if request.method == "POST":
        db.execute(
            "UPDATE surveys SET title = ?, description = ? WHERE id = ?",
            (request.form.get("title", ""), request.form.get("description", ""), survey_id),
        )
        db.commit()
        flash("Anket kaydedildi.")
        return redirect(url_for("survey_edit", survey_id=survey_id))

    questions = db.execute(
        "SELECT * FROM questions WHERE survey_id = ? ORDER BY position", (survey_id,)
    ).fetchall()
    return render_template("survey_form.html", survey=survey, questions=questions)


@app.route("/survey/<int:survey_id>/question/add", methods=["POST"])
@login_required
def question_add(survey_id):
    db = get_db()
    qtype = request.form.get("qtype", "open")
    pos = db.execute(
        "SELECT COALESCE(MAX(position), -1) + 1 AS p FROM questions WHERE survey_id = ?", (survey_id,)
    ).fetchone()["p"]
    options = ["", ""] if qtype == "choice" else []
    db.execute(
        "INSERT INTO questions (survey_id, position, qtype, text, options_json) VALUES (?, ?, ?, ?, ?)",
        (survey_id, pos, qtype, "", json.dumps(options, ensure_ascii=False)),
    )
    db.commit()
    return redirect(url_for("survey_edit", survey_id=survey_id))


@app.route("/question/<int:question_id>/update", methods=["POST"])
@login_required
def question_update(question_id):
    db = get_db()
    q = db.execute("SELECT * FROM questions WHERE id = ?", (question_id,)).fetchone()
    if not q:
        abort(404)
    text = request.form.get("text", "")
    options = [o for o in request.form.getlist("options") if o.strip() != ""]
    db.execute(
        "UPDATE questions SET text = ?, options_json = ? WHERE id = ?",
        (text, json.dumps(options, ensure_ascii=False), question_id),
    )
    db.commit()
    return redirect(url_for("survey_edit", survey_id=q["survey_id"]))


@app.route("/question/<int:question_id>/delete", methods=["POST"])
@login_required
def question_delete(question_id):
    db = get_db()
    q = db.execute("SELECT * FROM questions WHERE id = ?", (question_id,)).fetchone()
    if not q:
        abort(404)
    db.execute("DELETE FROM questions WHERE id = ?", (question_id,))
    db.commit()
    return redirect(url_for("survey_edit", survey_id=q["survey_id"]))


@app.route("/survey/<int:survey_id>/students", methods=["GET", "POST"])
@login_required
def students_upload(survey_id):
    db = get_db()
    survey = db.execute("SELECT * FROM surveys WHERE id = ?", (survey_id,)).fetchone()
    if not survey:
        abort(404)

    if request.method == "POST":
        file = request.files.get("csv_file")
        manual = request.form.get("manual_list", "")
        rows = []
        if file and file.filename:
            content = file.stream.read().decode("utf-8-sig")
            reader = csv.reader(io.StringIO(content))
            for r in reader:
                if len(r) >= 2 and r[0].strip().lower() not in ("ad soyad", "adsoyad", "name"):
                    rows.append((r[0].strip(), r[1].strip()))
        elif manual.strip():
            for line in manual.strip().splitlines():
                parts = [p.strip() for p in line.split(",")]
                if len(parts) >= 2:
                    rows.append((parts[0], parts[1]))

        added = 0
        for name, no in rows:
            if not name or not no:
                continue
            token = secrets.token_urlsafe(8)
            db.execute(
                "INSERT INTO students (survey_id, full_name, student_no, token) VALUES (?, ?, ?, ?)",
                (survey_id, name, no, token),
            )
            added += 1
        db.commit()
        flash(f"{added} öğrenci eklendi ve link/QR üretildi.")
        return redirect(url_for("students_upload", survey_id=survey_id))

    students = db.execute(
        "SELECT * FROM students WHERE survey_id = ? ORDER BY id", (survey_id,)
    ).fetchall()
    return render_template("students_upload.html", survey=survey, students=students)


@app.route("/survey/<int:survey_id>/publish", methods=["POST"])
@login_required
def survey_publish(survey_id):
    db = get_db()
    q_count = db.execute(
        "SELECT COUNT(*) c FROM questions WHERE survey_id = ?", (survey_id,)
    ).fetchone()["c"]
    if q_count == 0:
        flash("Yayınlamadan önce en az bir soru ekleyin.")
        return redirect(url_for("survey_edit", survey_id=survey_id))
    db.execute("UPDATE surveys SET published = 1 WHERE id = ?", (survey_id,))
    db.commit()
    flash("Anket yayınlandı.")
    return redirect(url_for("students_upload", survey_id=survey_id))


@app.route("/survey/<int:survey_id>/unpublish", methods=["POST"])
@login_required
def survey_unpublish(survey_id):
    db = get_db()
    db.execute("UPDATE surveys SET published = 0 WHERE id = ?", (survey_id,))
    db.commit()
    return redirect(url_for("dashboard"))


@app.route("/survey/<int:survey_id>/delete", methods=["POST"])
@login_required
def survey_delete(survey_id):
    db = get_db()
    db.execute("DELETE FROM surveys WHERE id = ?", (survey_id,))
    db.commit()
    return redirect(url_for("dashboard"))


@app.route("/qr/<token>.png")
def qr_image(token):
    fill_url = url_for("fill_id", token=token, _external=True)
    img = qrcode.make(fill_url)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return Response(buf.getvalue(), mimetype="image/png")


@app.route("/survey/<int:survey_id>/students/export")
@login_required
def students_export(survey_id):
    db = get_db()
    students = db.execute(
        "SELECT full_name, student_no, used, used_at FROM students WHERE survey_id = ? ORDER BY id",
        (survey_id,),
    ).fetchall()
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["Ad Soyad", "Öğrenci No", "Doldurdu mu", "Tarih"])
    for s in students:
        writer.writerow([s["full_name"], s["student_no"], "Evet" if s["used"] else "Hayır", s["used_at"] or ""])
    return Response(
        out.getvalue().encode("utf-8-sig"), mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename=katilim_{survey_id}.csv"},
    )


@app.route("/survey/<int:survey_id>/responses/export")
@login_required
def responses_export(survey_id):
    db = get_db()
    questions = db.execute(
        "SELECT * FROM questions WHERE survey_id = ? ORDER BY position", (survey_id,)
    ).fetchall()
    responses = db.execute(
        "SELECT * FROM responses WHERE survey_id = ? ORDER BY id", (survey_id,)
    ).fetchall()
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow([q["text"] for q in questions])
    for r in responses:
        answers = json.loads(r["answers_json"])
        writer.writerow([answers.get(str(q["id"]), "") for q in questions])
    return Response(
        out.getvalue().encode("utf-8-sig"), mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename=cevaplar_{survey_id}.csv"},
    )


@app.route("/survey/<int:survey_id>/results")
@login_required
def results(survey_id):
    db = get_db()
    survey = db.execute("SELECT * FROM surveys WHERE id = ?", (survey_id,)).fetchone()
    if not survey:
        abort(404)
    questions = db.execute(
        "SELECT * FROM questions WHERE survey_id = ? ORDER BY position", (survey_id,)
    ).fetchall()
    responses = db.execute(
        "SELECT * FROM responses WHERE survey_id = ?", (survey_id,)
    ).fetchall()
    parsed_responses = [json.loads(r["answers_json"]) for r in responses]

    charts = []
    for q in questions:
        qid = str(q["id"])
        if q["qtype"] == "choice":
            options = json.loads(q["options_json"])
            counts = {o: 0 for o in options}
            for ans in parsed_responses:
                v = ans.get(qid)
                if v in counts:
                    counts[v] += 1
            charts.append({"text": q["text"], "type": "choice", "labels": list(counts.keys()), "values": list(counts.values())})
        elif q["qtype"] == "likert":
            counts = {str(v): 0 for v in range(1, 6)}
            for ans in parsed_responses:
                v = str(ans.get(qid, ""))
                if v in counts:
                    counts[v] += 1
            charts.append({"text": q["text"], "type": "likert", "labels": list(counts.keys()), "values": list(counts.values())})
        else:
            texts = [ans.get(qid, "") for ans in parsed_responses if ans.get(qid)]
            charts.append({"text": q["text"], "type": "open", "texts": texts})

    total_students = db.execute(
        "SELECT COUNT(*) c FROM students WHERE survey_id = ?", (survey_id,)
    ).fetchone()["c"]

    return render_template(
        "results.html", survey=survey, charts=charts,
        response_count=len(responses), total_students=total_students,
    )


# ---------- Öğrenci akışı ----------

@app.route("/s/<token>")
def fill_id(token):
    db = get_db()
    student = db.execute("SELECT * FROM students WHERE token = ?", (token,)).fetchone()
    if not student:
        return render_template("fill_done.html", message="Bu link geçerli değil.")
    if student["used"]:
        return render_template("fill_done.html", message="Bu link daha önce kullanılmış. Aynı ankete ikinci kez katılamazsınız.")
    survey = db.execute("SELECT * FROM surveys WHERE id = ?", (student["survey_id"],)).fetchone()
    if not survey or not survey["published"]:
        return render_template("fill_done.html", message="Bu anket şu anda aktif değil.")
    return render_template("fill_id.html", token=token, student=student, survey=survey)


@app.route("/s/<token>/anket", methods=["GET", "POST"])
def fill_survey(token):
    db = get_db()
    student = db.execute("SELECT * FROM students WHERE token = ?", (token,)).fetchone()
    if not student or student["used"]:
        return render_template("fill_done.html", message="Bu link geçerli değil veya daha önce kullanılmış.")
    survey = db.execute("SELECT * FROM surveys WHERE id = ?", (student["survey_id"],)).fetchone()
    questions = db.execute(
        "SELECT * FROM questions WHERE survey_id = ? ORDER BY position", (survey["id"],)
    ).fetchall()

    if request.method == "POST":
        answers = {}
        for q in questions:
            key = f"q{q['id']}"
            val = request.form.get(key, "").strip()
            if not val:
                flash("Lütfen tüm soruları cevaplayın.")
                return render_template("fill_survey.html", token=token, survey=survey, questions=questions)
            answers[str(q["id"])] = int(val) if q["qtype"] == "likert" else val

        # Cevap, öğrenci kaydına hiçbir şekilde referans vermeden ayrı bir satır olarak eklenir.
        db.execute(
            "INSERT INTO responses (survey_id, answers_json) VALUES (?, ?)",
            (survey["id"], json.dumps(answers, ensure_ascii=False)),
        )
        # Token sadece "kullanıldı" olarak işaretlenir; hangi cevaba karşılık geldiği tutulmaz.
        db.execute(
            "UPDATE students SET used = 1, used_at = ? WHERE id = ?",
            (datetime.now(timezone.utc).isoformat(), student["id"]),
        )
        db.commit()
        return render_template("fill_done.html", message="Anket gönderildi. Katılımınız için teşekkürler.", success=True)

    return render_template("fill_survey.html", token=token, survey=survey, questions=questions)


with app.app_context():
    init_db()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
