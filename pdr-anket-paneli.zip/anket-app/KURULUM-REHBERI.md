# PDR Anket Paneli — Kurulum Rehberi

Bu rehber, hiç yazılım bilginiz olmasa bile uygulamayı internete açık, kendi adresi olan bir web sitesi haline getirmenizi sağlar. Toplam süre yaklaşık 20-30 dakika. Komut satırı (siyah ekran) kullanmanıza gerek yok — her şey tarayıcıdan, tıklayarak yapılır.

**Maliyet:** Bu rehber Render.com'un **ücretsiz planını** kullanır — kredi kartı gerekmez. Bunun karşılığında iki şey bilmeniz gerekiyor (aşağıda "Ücretsiz planın bilmeniz gereken yönleri" bölümünde ayrıntılı):

1. Anket verileri, siz sonuçları CSV olarak indirmeden servis "uykuya" girip tekrar uyanırsa silinebilir.
2. Bir süre kullanılmayınca sunucu "uykuya" geçer; bir sonraki girişte açılması 30-50 saniye sürebilir.

Siz sonuçları zaten her anket sonrası dışa aktardığınız için bu sizin için sorun değil — ama **ne zaman** silinebileceğini bilmeniz önemli, aşağıda anlatıyorum.

---

## Bölüm 1 — Dosyaları GitHub'a yükleyin (10 dk)

GitHub, kodunuzu sakladığınız ücretsiz bir depo hizmetidir. Render, uygulamanızı buradan alıp çalıştıracak.

1. [github.com](https://github.com) adresine gidin, sağ üstten **Sign up** ile ücretsiz bir hesap açın (e-posta, kullanıcı adı, şifre yeterli).
2. Giriş yaptıktan sonra sağ üstteki **+** işaretine, ardından **New repository**'e tıklayın.
3. **Repository name** kutusuna `pdr-anket-paneli` yazın.
4. **Public** seçili kalsın, altındaki kutucuklardan hiçbirini işaretlemeyin.
5. **Create repository** butonuna basın.
6. Açılan sayfada **"uploading an existing file"** yazan mavi bağlantıya tıklayın.
7. Bilgisayarınızda bu rehberle birlikte aldığınız klasördeki **tüm dosya ve klasörleri** (app.py, requirements.txt, Procfile, render.yaml, templates klasörü, static klasörü — README ve bu rehber hariç tutulabilir) sürükleyip bırakın.
8. Sayfanın altındaki yeşil **Commit changes** butonuna basın.

Dosyalarınız artık GitHub'da. Adresi not edin: `https://github.com/KULLANICI-ADINIZ/pdr-anket-paneli`

---

## Bölüm 2 — Render.com'da yayınlayın (10 dk)

1. [render.com](https://render.com) adresine gidin, **Get Started** ile hesap açın — **"Sign up with GitHub"** seçeneğini kullanırsanız iki hesabınız otomatik bağlanır (en kolayı budur).
2. Render panelinde sağ üstten **New +** → **Blueprint** seçin.
3. Biraz önce oluşturduğunuz `pdr-anket-paneli` deposunu listeden seçip **Connect** deyin.
4. Render, yüklediğiniz `render.yaml` dosyasını otomatik tanır ve "pdr-anket-paneli" adında, **Free** plana ayarlı bir web servisi önerir. **Apply**'a basmadan önce şunu yapın:
5. Aşağıda **Environment Variables** (ortam değişkenleri) bölümünde iki alan göreceksiniz:
   - `ADMIN_USERNAME` → buraya kendi seçeceğiniz bir kullanıcı adı yazın (örn. `ogretmen`)
   - `ADMIN_PASSWORD` → buraya güçlü bir şifre yazın (bunu not edin, panel girişinde kullanacaksınız)
6. **Apply**'a basın — ücretsiz plan olduğu için kredi kartı istenmez.
7. Render otomatik olarak uygulamanızı kuracak; bu 2-4 dakika sürer. Ekranda loglar akacak, bitince üstte **Live** yazısını göreceksiniz.
8. Sayfanın üst kısmında `https://pdr-anket-paneli-xxxx.onrender.com` gibi bir adres göreceksiniz — bu sizin **kalıcı panel adresiniz** (adresin kendisi değişmez, silinen sadece içindeki veridir). Bunu tarayıcı favorilerinize ekleyin.

### Ücretsiz planın bilmeniz gereken yönleri

- **15 dakika kullanılmazsa sunucu uyur.** Kimse siteye girmezse Render sunucuyu otomatik kapatır. Bir sonraki ziyaretçi (siz ya da bir öğrenci) sayfayı açtığında sunucu yeniden ayağa kalkar — bu **30-50 saniye** sürer, sayfa o süre boyunca yükleniyor gibi görünür, normaldir.
- **Uyuyup uyanma anında veritabanı sıfırlanır.** Yani bir anketi sabah açtınız, öğrenciler ara ara (aralarında 15 dakikadan uzun boşluklar olacak şekilde) doldurdu diyelim — bu durumda sunucu araya uyuyup uyanabilir ve **o ana kadar toplanan cevaplar silinebilir.**
- **Bunun için önerilen kullanım şekli:** Anketi bir oturumda (öğrencileri art arda, örneğin bir ders saati içinde) doldurtun, bitirir bitirmez **Sonuçlar** sayfasından "Cevapları indir (CSV)" ve "Katılım listesini indir" ile dışa aktarın. Aynı gün içinde tekrar aynı ankete devam ederseniz, önceki CSV'yi zaten yedeklediğiniz için veri kaybı sorun olmaz.
- Panelde oluşturduğunuz anket **sorularının kendisi** (başlık, sorular, seçenekler) de bu ücretsiz planda kalıcı değildir — sunucu sıfırlandığında onlar da silinir. Pratik çözüm: anketi oluşturup yayınladıktan hemen sonra, aynı gün içinde kullanın; bir sonraki anket için soruları tekrar (birkaç dakikalık bir iş) girersiniz.

---

## Bölüm 3 — İlk giriş

1. Yukarıdaki adresi tarayıcıda açın.
2. Render'da girdiğiniz kullanıcı adı ve şifre ile giriş yapın.
3. **+ Yeni anket** ile ilk anketinizi oluşturun, soruları ekleyin.
4. **Yayınla** dedikten sonra **Öğrenciler / Linkler** sayfasından öğrenci listenizi (Excel'den kopyala-yapıştır ya da CSV) girin — her öğrenci için otomatik tek kullanımlık link ve QR kod üretilecek.
5. Linkleri veya QR kodları öğrencilerle paylaşın (yansıya yansıtabilir, e-posta/mesaj ile gönderebilir ya da tek tek gösterebilirsiniz).
6. **Sonuçlar** sayfasından canlı grafikleri takip edin.

Telefondan kullanmak için ekstra bir şey kurmanıza gerek yok — aynı adresi telefonun tarayıcısından açmanız yeterli. İsterseniz tarayıcıda "Ana ekrana ekle" seçeneğiyle ikon haline getirebilirsiniz.

---

## Sık sorulanlar

**Öğrenciler nereden girebilir?**
İnternet bağlantısı olan her yerden — okul, ev, telefon fark etmez. Her link tek bir öğrenciye özeldir ve bir kez kullanıldıktan sonra kapanır.

**Verilerim güvende mi, kim erişebilir?**
Panel kullanıcı adı/şifre ile korunur, sizin dışınızda kimse giremez. Ücretsiz planda veritabanı kalıcı değildir (yukarıdaki "Ücretsiz planın bilmeniz gereken yönleri" bölümüne bakın) — bu yüzden asıl kayıt olarak indirdiğiniz CSV dosyalarını kendi bilgisayarınızda saklamanız önerilir.

**İleride kalıcı depolamaya geçmek istersem?**
Render panelinde servisinizin **Settings** sekmesinden plana "Starter" (aylık ~7 dolar) yükseltip bir "Disk" eklemeniz yeterli — kodda hiçbir değişiklik gerekmez.

**Şifremi sonradan değiştirebilir miyim?**
Evet — Render panelinde servisinize girip **Environment** sekmesinden `ADMIN_PASSWORD` değerini güncelleyip kaydetmeniz yeterli; uygulama birkaç saniyede yeniden başlar.

**Bir şey ters giderse ne yaparım?**
Render panelindeki **Logs** sekmesinde hata mesajlarını görebilirsiniz. Buradan bir ekran görüntüsü alıp bana gönderirseniz sorunu birlikte çözeriz.
